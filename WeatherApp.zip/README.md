# WeatherApp

Please Use XCode 11 for the building, as I have developed this only over XCode 11, so that might have problem on older XCodes, as there is a new file named: 'SceneDelegate.swift' which might not get supported in older xcodes (haven't checked it though).

